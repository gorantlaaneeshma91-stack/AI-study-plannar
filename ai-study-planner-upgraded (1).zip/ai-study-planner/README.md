# NextMind AI — Adaptive Study Planner

A polished, responsive full-stack study planner based on the supplied NextMind AI reference design. The planner is intentionally **subject-agnostic**: it can be used for engineering, medicine, science, mathematics, commerce, law, languages, school subjects, certifications, competitive exams and custom topic lists.

## Included

- Premium dark/blue responsive UI
- No numbered heading on the hero
- Syllabus paste + PDF/TXT/MD/CSV upload
- Automatic topic extraction
- Exam-date-aware scheduling
- Daily study-time limits
- Weak-topic prioritization
- Spaced review, active recall, practice and buffer sessions
- Adaptive plan regeneration after quiz results
- Quiz generation endpoint
- Local progress persistence with localStorage
- Today/command-center dashboard
- Readiness and topic coverage analytics
- Demo/local engine that works without an API key
- Optional OpenAI-powered plan and quiz generation
- Server-side API key handling

## Run on Windows

1. Install Node.js 18+.
2. Extract this folder.
3. Open Command Prompt in the project folder.
4. Run:

```bash
npm install
npm start
```

5. Open http://localhost:3000

Or double-click `start-windows.bat`.

## Enable real AI

Copy `.env.example` to `.env` and add your API key:

```env
OPENAI_API_KEY=your_api_key_here
OPENAI_MODEL=gpt-4o-mini
PORT=3000
```

Never put the API key inside `public/app.js` or `index.html`.

## Important behavior

The local planner is deterministic and does not require AI. It schedules sessions before the exam date, respects the daily-hour limit, prioritizes weak topics, and adds review/practice/buffer blocks. This makes the application usable even when the AI API is unavailable.

The AI endpoint is used as an enhancement, not as the only scheduling mechanism.

## Project structure

```text
ai-study-planner/
├── public/
│   ├── index.html
│   ├── style.css
│   └── app.js
├── server.js
├── package.json
├── .env.example
├── start-windows.bat
└── README.md
```

## Production next steps

For a hosted production version, add authentication, a database (Postgres/Supabase), server-side per-user data isolation, calendar integration, scheduled notifications, stronger syllabus parsing for scanned PDFs, automated tests, and rate limiting.
