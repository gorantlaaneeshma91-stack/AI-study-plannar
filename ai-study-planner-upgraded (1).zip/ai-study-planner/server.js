import express from 'express';
import multer from 'multer';
import pdfParse from 'pdf-parse';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';

dotenv.config();
const __filename=fileURLToPath(import.meta.url);
const __dirname=path.dirname(__filename);
const app=express();
const upload=multer({storage:multer.memoryStorage(),limits:{fileSize:10*1024*1024}});
app.use(express.json({limit:'2mb'}));
app.use(express.static(path.join(__dirname,'public')));

function cleanTopic(line){return line.replace(/^\s*(?:[-*•▪◦]|\d+[.)]|[├└─│]+)\s*/,'').replace(/\s+/g,' ').trim()}
function parseTopics(text=''){
  const lines=text.split(/\r?\n/).map(cleanTopic).filter(Boolean);
  const topics=[];
  for(const line of lines){
    if(line.length<2)continue;
    if(/^(syllabus|course outline|contents?|topics?|subject|units?|chapters?|modules?)$/i.test(line))continue;
    const pieces=line.split(/\s{2,}|\s*[|;]\s*/).map(x=>x.trim()).filter(Boolean);
    for(const p of pieces)if(p.length>1)topics.push(p.slice(0,120));
  }
  return [...new Set(topics)].slice(0,80);
}
function clamp(n,min,max){return Math.max(min,Math.min(max,n))}
function dateISO(d){return d.toISOString().slice(0,10)}
function addDays(s,n){const d=new Date(s+'T12:00:00');d.setDate(d.getDate()+n);return dateISO(d)}
function daysBetween(a,b){return Math.ceil((new Date(b+'T12:00:00')-new Date(a+'T12:00:00'))/86400000)}
function normalizedWeak(weak=[]){return weak.map(x=>String(x).toLowerCase()).filter(Boolean)}
function buildLocalPlan(b){
  let topics=(b.topics?.length?b.topics:parseTopics(b.syllabus||'')).filter(Boolean);
  if(!topics.length)topics=['Core concepts','Worked examples','Practice problems','Revision'];
  const today=dateISO(new Date());
  let exam=b.examDate||addDays(today,14);
  if(daysBetween(today,exam)<2)exam=addDays(today,7);
  const available=clamp(daysBetween(today,exam),3,90);
  const days=clamp(Math.min(available-1,Number(b.studyDays)||available-1),3,60);
  const hours=clamp(Number(b.hoursPerDay)||2,.5,8);
  const weak=normalizedWeak(b.weakTopics||[]);
  const scored=topics.map((t,i)=>{const low=t.toLowerCase();const isWeak=weak.some(w=>low.includes(w)||w.includes(low));return{t,i,score:(isWeak?1000:0)+(topics.length-i)}}).sort((a,c)=>c.score-a.score);
  const ordered=scored.map(x=>x.t);
  const plan=[];
  const reviewEnabled=b.includeReviews!==false;
  const quizEnabled=b.includeQuizzes!==false;
  const bufferEnabled=b.includeBuffers!==false;
  for(let i=0;i<days;i++){
    const phase=i/days;
    let focus=ordered[i%ordered.length];
    let type='Study';
    let tasks=['Learn core ideas','Make concise notes','Practice retrieval'];
    let priority='Normal';
    if(i===days-1){focus='Final review';type='Review';tasks=['Rapid recall','Review weak areas','Exam-style questions'];priority='High'}
    else if(reviewEnabled&&i>0&&i%4===2){const prior=ordered[Math.max(0,(i-2)%ordered.length)];focus=prior;type='Review';tasks=['Active recall','Spaced review','Fix mistakes'];priority='Medium'}
    else if(quizEnabled&&i%5===4){type='Practice';tasks=['Timed practice','Self-check','5–10 question quiz'];priority='Medium'}
    const isWeak=weak.some(w=>focus.toLowerCase().includes(w));
    if(isWeak){priority='High';tasks=['Relearn difficult concept','Worked examples','Targeted practice',...(quizEnabled?['Topic quiz']:[])];}
    if(bufferEnabled&&i===Math.floor(days*.72)){type='Buffer';focus='Catch-up & consolidation';tasks=['Finish missed work','Consolidate notes','Revisit weakest concept'];priority='Medium'}
    plan.push({id:`session-${i+1}`,day:i+1,date:addDays(today,i),focus,duration:`${hours}h`,hours,tasks,priority,type,reason:isWeak?'Weak-topic priority':'Balanced coverage with spaced practice'});
  }
  return {title:'Your adaptive study plan',examDate:exam,dailyHours:hours,topics:ordered,weakTopics:b.weakTopics||[],strategy:'Deadline-aware scheduling + active recall + spaced review',plan,generatedBy:'NextMind local planning engine'};
}

async function callOpenAI(prompt){
  const key=process.env.OPENAI_API_KEY;if(!key)return null;
  const model=process.env.OPENAI_MODEL||'gpt-4o-mini';
  const r=await fetch('https://api.openai.com/v1/chat/completions',{method:'POST',headers:{'Content-Type':'application/json',Authorization:`Bearer ${key}`},body:JSON.stringify({model,temperature:.2,response_format:{type:'json_object'},messages:[{role:'system',content:'You are an expert educational planner. Return valid JSON only. Never invent an exam date or ignore time constraints. Prefer active recall, spaced review, realistic workload and transparent adaptation.'},{role:'user',content:prompt}]})});
  if(!r.ok)throw new Error(`AI API error ${r.status}: ${await r.text()}`);
  const data=await r.json();return JSON.parse(data.choices?.[0]?.message?.content||'{}');
}

app.post('/api/parse-syllabus',upload.single('file'),async(req,res)=>{try{if(!req.file)return res.status(400).json({error:'No file uploaded'});let text='';const isPDF=req.file.mimetype==='application/pdf'||req.file.originalname.toLowerCase().endsWith('.pdf');if(isPDF)text=(await pdfParse(req.file.buffer)).text;else text=req.file.buffer.toString('utf8');const topics=parseTopics(text);res.json({text,topics})}catch(e){res.status(500).json({error:e.message})}});

app.post('/api/generate-plan',async(req,res)=>{try{const b=req.body||{};const local=buildLocalPlan(b);const prompt=`Build an adaptive study plan for any academic subject. Inputs: topics=${JSON.stringify(local.topics)}, examDate=${local.examDate}, dailyHours=${local.dailyHours}, level=${b.level}, intensity=${b.intensity}, weakTopics=${JSON.stringify(b.weakTopics||[])}, quizzes=${b.includeQuizzes}, reviews=${b.includeReviews}, buffers=${b.includeBuffers}. Return JSON exactly shaped as {title,examDate,dailyHours,topics,weakTopics,strategy,plan:[{id,day,date,focus,duration,hours,tasks,priority,type,reason}]}. Dates must be between today and the day before examDate. Do not schedule more than dailyHours in a day. Prioritize weak topics and include active recall, practice and spaced review.`;const ai=await callOpenAI(prompt);if(ai?.plan?.length)res.json({...local,...ai,topics:ai.topics?.length?ai.topics:local.topics,weakTopics:ai.weakTopics||local.weakTopics});else res.json(local)}catch(e){res.status(500).json({error:e.message})}});

app.post('/api/adapt-plan',async(req,res)=>{try{const {plan,topic,score,weakTopics=[]}=req.body||{};if(!plan?.plan)return res.status(400).json({error:'Plan is required'});const local=buildLocalPlan({topics:plan.topics,weakTopics,examDate:plan.examDate,hoursPerDay:plan.dailyHours,studyDays:plan.plan.length,includeQuizzes:true,includeReviews:true,includeBuffers:true});const ai=await callOpenAI(`Adapt this study plan after a quiz result. Topic: ${topic}. Score: ${score}%. Weak topics: ${JSON.stringify(weakTopics)}. Existing plan: ${JSON.stringify(plan.plan)}. Return JSON with title, examDate, dailyHours, topics, weakTopics, strategy, plan. Move the weak topic earlier, add targeted practice/retrieval, preserve the exam date and daily hours.`);res.json(ai?.plan?.length?{...local,...ai}:local)}catch(e){res.status(500).json({error:e.message})}});

app.post('/api/generate-quiz',async(req,res)=>{try{const {topic,count=8,level='intermediate'}=req.body||{};if(!topic)return res.status(400).json({error:'Topic is required'});const n=clamp(Number(count)||8,3,10);const prompt=`Create ${n} accurate multiple-choice questions for the academic topic "${topic}" at ${level} level. Make questions conceptually meaningful, not generic. Return JSON {questions:[{question,options:[four strings],answer:number,explanation:string}]}. answer must be zero-based.`;const ai=await callOpenAI(prompt);if(ai?.questions?.length)return res.json({questions:ai.questions.slice(0,n)});const questions=Array.from({length:n},(_,i)=>({question:`Practice ${i+1}: Which statement is most relevant when studying ${topic}?`,options:[`A core principle of ${topic}`,`An unrelated topic`,`A contradictory claim`,`A random definition`],answer:0,explanation:'Demo mode question. Add OPENAI_API_KEY for topic-specific generated questions.'}));res.json({questions})}catch(e){res.status(500).json({error:e.message})}});

app.post('/api/evaluate',(req,res)=>{const {results=[],topic}=req.body||{};const score=results.length?Math.round(results.filter(x=>x.correct).length/results.length*100):0;const status=score<60?'weak':score<80?'needs-review':'strong';const recommendation=status==='weak'?`Increase ${topic} practice and revisit the core concept before moving on.`:status==='needs-review'?`Keep ${topic} in rotation and add one short retrieval review.`:`${topic} is currently strong. Move it to spaced maintenance review.`;res.json({topic,score,status,recommendation})});
app.get('/api/health',(_,res)=>res.json({ok:true,aiEnabled:Boolean(process.env.OPENAI_API_KEY)}));
app.get('*',(_,res)=>res.sendFile(path.join(__dirname,'public','index.html')));
const port=process.env.PORT||3000;app.listen(port,()=>console.log(`NextMind AI Study Planner running at http://localhost:${port}`));
